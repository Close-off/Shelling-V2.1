Author : @Close_off-prog

Version : 2.1

New : Optimization + new command : makefile. to create a makefile 
