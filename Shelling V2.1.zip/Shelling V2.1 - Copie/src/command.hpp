#ifndef __COMMAND__
    #define __COMMAND__

#include <string>

namespace cmd { // "cmd" for "command" not like "cmd" in windows
    bool makefile(std::string& filename);
    bool supfile(std::string& filename);
    bool makedir(std::string& dirname);
    bool supdir(std::string& dirname);
    bool goto_dir(std::string& dirname);
    void print_path();
    void print(std::string& x);
}

#endif
