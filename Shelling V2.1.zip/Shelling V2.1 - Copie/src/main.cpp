#include "command.hpp"
#include <string>
#include <iostream>
#include <filesystem>
#include <windows.h>

namespace fs = std::filesystem;

std::string n{"makefile"};

int main() {
    char systemRoot[MAX_PATH];
    DWORD length = GetEnvironmentVariable("SystemRoot", systemRoot, MAX_PATH);

    if (length > 0) {
        fs::current_path(systemRoot);
    }
    //---------------------------
    std::string input;
    std::string command, arg;
    //---------------------------
    while(1) {
      std::cout << "\r>" << std::flush;
      std::getline(std::cin, input);

      size_t pos = input.find(' ');

      if (pos != std::string::npos) {
          command = input.substr(0, pos);
          arg = input.substr(pos + 1);
      } else {
          command = input;
          arg = "";
      }

      //----------------------------

      if(command == "makefile") {
        cmd::makefile(arg);
      } else if(command == "makefile.") {
        cmd::makefile(n);
      } else if(command == "supfile") {
        cmd::supfile(arg);
      } else if(command == "makedir") {
        cmd::makedir(arg);
      } else if(command == "supdir") {
        cmd::supdir(arg);
      } else if(command == "goto") {
        cmd::goto_dir(arg);
      } else if(command == "print_path") {
        cmd::print_path();
      } else if(command == "print") {
        cmd::print(arg);
      } else {
        std::cout << "Invalid command!" << std::endl;
        break;
      }
      //----------------------------
    }
    return 0;
}
