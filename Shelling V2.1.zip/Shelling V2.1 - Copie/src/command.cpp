#include "command.hpp"
#include <iostream>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;

#define NAME_ERROR "Error of syntax"
#define ifCommandFile !filename.empty()
#define ifCommandDir !dirname.empty()

void create_file(const std::string& filename) {
    std::ofstream file{filename, std::ios::out};  // Pas besoin de double indirection
}

bool cmd::makefile(std::string& filename) {
    if (ifCommandFile) {
        create_file(filename);
    } else {
        std::cout << NAME_ERROR << std::endl;
        return false;
    }
    return true;
}

bool cmd::supfile(std::string& filename) {
    if (ifCommandFile && fs::exists(filename)) {
        fs::remove(filename);
        return true;
    } else {
        std::cout << NAME_ERROR << std::endl;
        return false;
    }
}

bool cmd::makedir(std::string& dirname) {
    if (ifCommandDir) {
        fs::create_directory(dirname);
        return true;
    } else {
        std::cout << NAME_ERROR << std::endl;
        return false;
    }
}

bool cmd::supdir(std::string& dirname) {
    if (ifCommandDir && fs::exists(dirname)) {
        fs::remove_all(dirname);
        return true;
    } else {
        std::cout << NAME_ERROR << std::endl;
        return false;
    }
}

bool cmd::goto_dir(std::string& dirname) {
    if (ifCommandDir && fs::exists(dirname)) {
        fs::current_path(dirname);
        return true;
    } else {
        std::cout << NAME_ERROR << " or the path is not valid" << std::endl;
        return false;
    }
}

void cmd::print_path() {
    std::cout << fs::current_path() << std::endl;
}

void cmd::print(std::string& x) {
    std::cout << x << std::endl;
}
